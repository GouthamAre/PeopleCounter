
import { useState, useEffect, createContext, useContext } from "react";

// Define user type
export type User = {
  id: string;
  email: string;
  name?: string;
};

// Define authentication context type
type AuthContextType = {
  user: User | null;
  signIn: (email: string, password: string) => Promise<User>;
  signUp: (email: string, password: string, name?: string) => Promise<User>;
  signOut: () => void;
  isLoading: boolean;
};

// Create the authentication context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user storage for demo purposes
const STORAGE_KEY = "people_counter_user";

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on initial load
  useEffect(() => {
    const storedUser = localStorage.getItem(STORAGE_KEY);
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  // Sign in function
  const signIn = async (email: string, password: string): Promise<User> => {
    try {
      setIsLoading(true);
      // Simulate API call with a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Validate email format
      if (!email.includes('@')) {
        throw new Error('Invalid email format');
      }
      
      // Validate password length
      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters');
      }
      
      // In a real app, this would call an API
      // For this demo, we'll create a mock user
      const user = { id: '1', email };
      
      // Store user in localStorage
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
      setUser(user);
      return user;
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Sign up function
  const signUp = async (email: string, password: string, name?: string): Promise<User> => {
    try {
      setIsLoading(true);
      // Simulate API call with a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Validate email format
      if (!email.includes('@')) {
        throw new Error('Invalid email format');
      }
      
      // Validate password length
      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters');
      }
      
      // In a real app, this would call an API
      // For this demo, we'll create a mock user
      const user = { id: '1', email, name };
      
      // Store user in localStorage
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
      setUser(user);
      return user;
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Sign out function
  const signOut = () => {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, signIn, signUp, signOut, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
