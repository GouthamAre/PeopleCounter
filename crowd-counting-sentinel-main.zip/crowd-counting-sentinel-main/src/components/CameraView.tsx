
import { useEffect, useRef, useState, useCallback } from "react";
import { detectPeople } from "@/lib/peopleDetection";
import { useToast } from "@/hooks/use-toast";

interface CameraViewProps {
  isActive: boolean;
  onPeopleCountChange?: (count: number) => void;
  onGenderCountsChange?: (maleCount: number, femaleCount: number) => void;
  onFightDetection?: (fighting: boolean) => void;
}

const CameraView = ({ 
  isActive, 
  onPeopleCountChange,
  onGenderCountsChange,
  onFightDetection 
}: CameraViewProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const [isInitialized, setIsInitialized] = useState(false);
  const [peopleCount, setPeopleCount] = useState(0);
  const [maleCount, setMaleCount] = useState(0);
  const [femaleCount, setFemaleCount] = useState(0);
  const [isFighting, setIsFighting] = useState(false);
  const animationFrameRef = useRef<number>();
  const fightAlertTimeout = useRef<NodeJS.Timeout | null>(null);
  const isProcessingRef = useRef(false);
  
  // Memoized detection function to avoid recreating it on each render
  const runDetection = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current || !isInitialized || isProcessingRef.current) {
      animationFrameRef.current = requestAnimationFrame(runDetection);
      return;
    }

    isProcessingRef.current = true;
    
    try {
      const result = await detectPeople(videoRef.current, canvasRef.current);
      
      // Check for fight detection
      if (result.isFighting !== isFighting) {
        setIsFighting(result.isFighting);
        if (onFightDetection) {
          onFightDetection(result.isFighting);
        }
        
        if (result.isFighting) {
          // Clear any existing timeout
          if (fightAlertTimeout.current) {
            clearTimeout(fightAlertTimeout.current);
          }
          
          // Auto-clear fight detection after 10 seconds if no new fighting is detected
          fightAlertTimeout.current = setTimeout(() => {
            setIsFighting(false);
            if (onFightDetection) {
              onFightDetection(false);
            }
          }, 10000);
        }
      }
      
      // Only update count if it changed to reduce renders
      if (result.peopleCount !== peopleCount && result.peopleCount >= 0) {
        setPeopleCount(result.peopleCount);
        if (onPeopleCountChange) {
          onPeopleCountChange(result.peopleCount);
        }
      }
      
      // Update gender counts
      if ((result.maleCount !== maleCount || result.femaleCount !== femaleCount) && 
          (result.maleCount >= 0 && result.femaleCount >= 0)) {
        setMaleCount(result.maleCount);
        setFemaleCount(result.femaleCount);
        if (onGenderCountsChange) {
          onGenderCountsChange(result.maleCount, result.femaleCount);
        }
      }
    } catch (error) {
      console.error("Detection error:", error);
    } finally {
      isProcessingRef.current = false;
    }
    
    // Continue the detection loop
    animationFrameRef.current = requestAnimationFrame(runDetection);
  }, [isInitialized, onPeopleCountChange, peopleCount, isFighting, onFightDetection, maleCount, femaleCount, onGenderCountsChange]);

  useEffect(() => {
    if (!isActive) return;

    const initializeCamera = async () => {
      try {
        const constraints = { 
          video: { 
            facingMode: "user",
            width: { ideal: 640 },
            height: { ideal: 480 }
          } 
        };
        
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setIsInitialized(true);
          toast({
            title: "Camera Ready",
            description: "People detection is now active",
            variant: "default",
          });
        }
      } catch (error) {
        toast({
          title: "Camera Error",
          description: "Unable to access camera. Please check permissions.",
          variant: "destructive",
        });
      }
    };

    initializeCamera();

    return () => {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      
      // Clear timeout on unmount
      if (fightAlertTimeout.current) {
        clearTimeout(fightAlertTimeout.current);
      }
    };
  }, [isActive, toast]);

  useEffect(() => {
    if (!isInitialized) return;

    // Start continuous detection
    animationFrameRef.current = requestAnimationFrame(runDetection);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isInitialized, runDetection]);

  return (
    <div className="relative rounded-2xl overflow-hidden bg-zinc-900 aspect-video">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover"
      />
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
      />
      {!isActive && (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-900/90 text-white">
          Initializing camera...
        </div>
      )}
      <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-semibold">
        People Count: {peopleCount}
      </div>
      <div className="absolute top-14 right-4 flex flex-col gap-1">
        <div className="bg-blue-600/80 text-white px-3 py-1 rounded-full text-sm font-semibold">
          Male: {maleCount}
        </div>
        <div className="bg-pink-600/80 text-white px-3 py-1 rounded-full text-sm font-semibold">
          Female: {femaleCount}
        </div>
      </div>
    </div>
  );
};

export default CameraView;
