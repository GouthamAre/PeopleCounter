
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { LogIn, UserPlus } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useEffect } from "react";

const Index = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    // Redirect to home if already logged in
    if (user) {
      navigate("/home");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-zinc-100 to-zinc-200 p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <div className="mb-2">
          <span className="px-3 py-1 text-xs font-medium bg-zinc-900 text-white rounded-full">
            Real-time Analysis
          </span>
        </div>
        <h1 className="text-4xl font-bold mb-4 text-zinc-900">People Counter</h1>
        <p className="text-zinc-600 mb-8 max-w-md">
          Advanced real-time people counting using machine learning. Login or sign up to begin monitoring.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={() => navigate("/login")}
            className="group relative overflow-hidden rounded-full px-8 py-6 bg-zinc-900 hover:bg-zinc-800 text-white transition-all duration-300"
          >
            <span className="relative z-10 flex items-center gap-2">
              <LogIn className="w-5 h-5" />
              Login
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-zinc-800 to-zinc-900 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Button>

          <Button
            onClick={() => navigate("/signup")}
            className="group relative overflow-hidden rounded-full px-8 py-6 bg-zinc-200 hover:bg-zinc-300 text-zinc-900 transition-all duration-300"
          >
            <span className="relative z-10 flex items-center gap-2">
              <UserPlus className="w-5 h-5" />
              Sign Up
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-zinc-300 to-zinc-200 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default Index;
